#!/usr/bin/env python3
"""plot_results.py - quick visual summary of benchmark CSVs.

Usage:
    pip install pandas matplotlib
    python3 plot_results.py ./bench_results
"""
import os, sys
import pandas as pd
import matplotlib.pyplot as plt

OUT = sys.argv[1] if len(sys.argv) > 1 else "./bench_results"

def savings_plot():
    p = os.path.join(OUT, "savings.csv")
    if not os.path.exists(p): return
    df = pd.read_csv(p)
    fig, ax = plt.subplots(figsize=(8,5))
    for iv, sub in df.groupby("interval_ms"):
        for sz, ss in sub.groupby("file_size_mb"):
            ss = ss.sort_values("share_pct")
            ax.plot(ss.share_pct, ss.saved_kb / 1024,
                    marker='o', label=f"{sz}MB iv={iv}ms")
    ax.set_xlabel("Share %"); ax.set_ylabel("Saved (MB)")
    ax.set_title("Memory saved vs share% (per file size, scan interval)")
    ax.legend(fontsize=7); ax.grid(True)
    plt.tight_layout(); plt.savefig(os.path.join(OUT, "savings.png")); plt.close()
    print("wrote savings.png")

def latency_plot():
    p = os.path.join(OUT, "op_latency.csv")
    if not os.path.exists(p): return
    df = pd.read_csv(p)
    pivot = df.pivot_table(
        index=["file_size_mb","share_pct","op"],
        columns="phase", values="time_ms", aggfunc="mean").reset_index()
    pivot["overhead_pct"] = 100*(pivot["merged"] - pivot["unmerged"]) / pivot["unmerged"]
    fig, ax = plt.subplots(figsize=(9,5))
    for op, sub in pivot.groupby("op"):
        sub = sub.sort_values("file_size_mb")
        ax.plot(sub.file_size_mb, sub.overhead_pct, marker='o', label=op)
    ax.axhline(0, color="grey", lw=0.5)
    ax.set_xscale("log"); ax.set_xlabel("File size (MB, log)")
    ax.set_ylabel("Merged-vs-unmerged overhead (%)")
    ax.set_title("Op latency overhead due to dedup")
    ax.legend(); ax.grid(True)
    plt.tight_layout(); plt.savefig(os.path.join(OUT, "op_latency.png")); plt.close()
    print("wrote op_latency.png")

def pressure_plot():
    p = os.path.join(OUT, "pressure.csv")
    if not os.path.exists(p): return
    df = pd.read_csv(p)
    fig, axes = plt.subplots(1, 2, figsize=(12,4))
    for label, sub in df.groupby("label"):
        sub = sub[sub.files_loaded > 0]
        axes[0].plot(sub.files_loaded, sub.cached_kb/1024, marker='o', label=label)
        axes[1].plot(sub.files_loaded, sub.swap_used_kb/1024, marker='o', label=label)
    axes[0].set(title="Cached during sequential load",
                xlabel="files loaded", ylabel="Cached (MB)")
    axes[1].set(title="Swap used during sequential load",
                xlabel="files loaded", ylabel="Swap (MB)")
    for a in axes: a.legend(fontsize=7); a.grid(True)
    plt.tight_layout(); plt.savefig(os.path.join(OUT, "pressure.png")); plt.close()
    print("wrote pressure.png")

def scanner_plot():
    p = os.path.join(OUT, "scanner_profile.csv")
    if not os.path.exists(p): return
    df = pd.read_csv(p)
    fig, ax = plt.subplots(figsize=(8,5))
    ax.scatter(df.file_size_mb * df.n_files, df.cpu_avg_pct,
               c=df.interval_ms, cmap="viridis", s=60)
    for _, r in df.iterrows():
        ax.annotate(f"{r.share_pct}%", (r.file_size_mb*r.n_files, r.cpu_avg_pct),
                    fontsize=6, alpha=0.6)
    ax.set_xscale("log")
    ax.set_xlabel("Total scanned data (MB, log)")
    ax.set_ylabel("Scanner avg CPU%")
    ax.set_title("Scanner CPU usage (color = interval ms, label = share%)")
    plt.tight_layout(); plt.savefig(os.path.join(OUT,"scanner_profile.png")); plt.close()
    print("wrote scanner_profile.png")

savings_plot(); latency_plot(); pressure_plot(); scanner_plot()
print("done.")
